/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package server;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author kamra
 */
public class handler implements IDBHandler {
     Connection con;
     product p;
public handler(){
    
try {
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/sddb", "root","");
            System.out.println("conection establisted");
        } catch (SQLException ex) {
            Logger.getLogger(handler.class.getName()).log(Level.SEVERE, null, ex);
        }
}


    @Override
    public void add(product p) {
        String qurey="INSERT INTO product(name,description,price) values "+"('"+p.getName()+"','"+p.getDesc()+"','"+p.getPrice()+"')";
        try {
            Statement st=con.createStatement();
            int r=st.executeUpdate(qurey);
            if(r!=0)
            {
              JOptionPane.showMessageDialog(null, "Record Inserted!!!");
            }
        } catch (SQLException ex) {
            Logger.getLogger(handler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    

    @Override
    public void edit(product p) throws RemoteException {
   
      String qurey="Update product set name='"+p.name+"',description='"+p.getDesc()+"',price='"+p.getPrice()+"' where id='"+1+"'";
      try {
            Statement st=con.createStatement();
            int r=st.executeUpdate(qurey);
            if(r!=0)
            {
              JOptionPane.showMessageDialog(null, "Record edited!!!");
            }
        } catch (SQLException ex) {
            Logger.getLogger(handler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
   
    
    
}
