/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package server;

import java.rmi.AlreadyBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author kamra
 */
public class server {
    
    public  static void main(String[] args){
     try {
            IDBHandler a=new handler();
            IDBHandler stub = (IDBHandler) UnicastRemoteObject.exportObject(a,0);

            // Bind the remote object's stub in the registry
            Registry registry = LocateRegistry.createRegistry(1012);
            registry.bind("add", stub);
            System.out.println(" Server ready");
           
            
            
        } catch (RemoteException ex) {
            Logger.getLogger(server.class.getName()).log(Level.SEVERE, null, ex);
        } catch (AlreadyBoundException ex) {
            Logger.getLogger(server.class.getName()).log(Level.SEVERE, null, ex);
        } 
     
            
            try {
            IDBHandler add=new handler();
            IDBHandler st=(IDBHandler) UnicastRemoteObject.exportObject(add, 0);
            Registry registry1 = LocateRegistry.createRegistry(1014);
            registry1.bind("edit", st);
           
            
            
        } catch (RemoteException ex) {
            Logger.getLogger(server.class.getName()).log(Level.SEVERE, null, ex);
        } catch (AlreadyBoundException ex) {
            Logger.getLogger(server.class.getName()).log(Level.SEVERE, null, ex);
        } 
    }
}
